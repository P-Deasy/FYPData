	@Override
	public String toString() {
		return "Customer{" +
				"id=" + id +
				", name='" + name + '\'' +
				", customerNumber='" + customerNumber + '\'' +
				", accounts=" + accounts +
				", devices=" + devices +
				'}';
	}
