	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class[] {
				StrIntTestEntity.class,
				SetRefEdEmbIdEntity.class,
				SetRefIngEmbIdEntity.class,
				CollectionRefEdEntity.class,
				CollectionRefIngEntity.class
		};
	}
