	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				CarModel.class,
				Manufacturer.class,
				Model.class,
				Light.class
				//Lighter.class xml only entuty
		};
	}
