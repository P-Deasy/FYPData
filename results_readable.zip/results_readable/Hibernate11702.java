   @Override
   public String toString() {
      return "Family{" +
            "id=" + id +
            ", name='" + name + '\'' +
            ", secondName='" + secondName + '\'' +
            ", members=" + members +
            ", version=" + version +
            '}';
   }
