	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class<?>[] {
			Person.class,
			Partner.class,
            Phone.class,
			Call.class,
			CreditCardPayment.class,
			WireTransferPayment.class,
			SpaceShip.class,
			Captain.class,
		};
	}
