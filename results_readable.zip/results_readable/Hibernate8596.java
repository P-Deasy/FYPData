	@Override
	public String[] getMappings() {
		return new String[] {
			"legacy/MasterDetail.hbm.xml",
			"legacy/Custom.hbm.xml",
			"legacy/Category.hbm.xml",
			"legacy/Nameable.hbm.xml",
			"legacy/SingleSeveral.hbm.xml",
			"legacy/WZ.hbm.xml",
			"legacy/UpDown.hbm.xml",
			"legacy/Eye.hbm.xml"
		};
	}
