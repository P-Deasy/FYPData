	public void release() {
		preCreates.clear();
		postCreates.clear();

		preRemoves.clear();
		postRemoves.clear();

		preUpdates.clear();
		postUpdates.clear();

		postLoads.clear();
	}
