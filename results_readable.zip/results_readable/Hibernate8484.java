	public void lock(
		Serializable id,
		Object version,
		Object object,
		LockOptions lockOptions,
		SharedSessionContractImplementor session
	) throws HibernateException {

		throw new UnsupportedOperationException();
	}
