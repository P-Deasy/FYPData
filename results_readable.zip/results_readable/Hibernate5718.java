	@Override
	public Class[] getAnnotatedClasses() {
		return new Class[]{
				Customer.class,
				Order.class,
				OrderLine.class,
				Product.class,
				PurchaseOrg.class,
				Facility.class,
				Site.class
		};
	}
