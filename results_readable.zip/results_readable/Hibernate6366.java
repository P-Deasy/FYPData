	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[]{
				B.class,
				C.class,
				D.class,
				E.class,
				F.class,
				G.class
		};
	}
