	public NonEncapsulatedEntityIdentifierDescription(
			EntityReference entityReference,
			ExpandingCompositeQuerySpace compositeQuerySpace,
			CompositeType compositeType,
			PropertyPath propertyPath) {
		super(
				entityReference,
				compositeQuerySpace,
				compositeType,
				propertyPath
		);
	}
