	public TransitiveOverrideEntity(
			String str1,
			Integer number1,
			Integer id,
			String str2,
			Integer number2,
			String str3) {
		super( str1, number1, id, str2, number2 );
		this.str3 = str3;
	}
