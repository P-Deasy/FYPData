	@Test
	public void testEntityMappingPropertiesAreNotIgnored() {
		throw new RuntimeException();
//		Session s = openSession();
//		Transaction tx = s.beginTransaction();
//
//		HabitatSpeciesLink link = new HabitatSpeciesLink();
//		link.setHabitatId( 1l );
//		link.setSpeciesId( 1l );
//		s.persist( link );
//
//		Query q = s.getNamedQuery( "testQuery" );
//		assertEquals( 1, q.list().size() );
//
//		tx.rollback();
//		s.close();
	}
