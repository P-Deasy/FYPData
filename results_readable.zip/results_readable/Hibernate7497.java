	public Address(
			Integer id,
			String streetLine1,
			String streetLine2,
			PostalArea postalArea) {
		this.id = id;
		this.streetLine1 = streetLine1;
		this.streetLine2 = streetLine2;
		this.postalArea = postalArea;
	}
